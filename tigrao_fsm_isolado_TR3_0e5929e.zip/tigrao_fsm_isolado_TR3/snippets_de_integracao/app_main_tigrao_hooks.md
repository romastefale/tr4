# Snippets de integração: `app/main.py`

## imports diretos do Tigrão no core — linhas 35-50

```python
0035: from app.moderation_tigrao import customize_router as tigrao_customize_router, ddx_router as tigrao_ddx_router, ddx_soft_router as tigrao_ddx_soft_router, member_tag_router as tigrao_member_tag_router, pinned_media_router as tigrao_pinned_media_router, router as tigrao_router
0036: from app.moderation_tigrao.customize_router import tigrao_receive_group_photo
0037: from app.moderation_tigrao.ddx_router import tigrao_ddx_receive_add_words, tigrao_ddx_receive_remove_words
0038: from app.moderation_tigrao.ddx_runtime import tigrao_ddx_preprocess_update
0039: from app.moderation_tigrao.ddx_soft_runtime import tigrao_ddx_soft_preprocess_update
0040: from app.moderation_tigrao.new_member_watch_router import router as tigrao_new_member_watch_router  # Sprint X4
0041: from app.moderation_tigrao.inline_router import router as tigrao_inline_x9_router  # Sprint X9
0042: from app.bot.new_member_watch_runtime import tigrao_new_member_watch_preprocess_update  # Sprint X4
0043: from app.moderation_tigrao.keyboards import home_keyboard
0044: from app.moderation_tigrao.member_tag_router import tigrao_member_tag_receive_text
0045: from app.moderation_tigrao.permissions import is_owner_private_message
0046: from app.moderation_tigrao.router import tigrao_private_text
0047: from app.moderation_tigrao.state import get_session, set_current_user as tigrao_set_current_user
0048: from app.btb.state import set_current_user as btb_set_current_user
0049: from app.moderation_tigrao.storage import remember_group
0050: from app.moderation_tigrao.texts import home_text
```

## detecção direta do comando /tigrao — linhas 86-92

```python
0086: def _is_tigrao_command(text_value: str | None) -> bool:
0087:     return _command_name(text_value) == "/tigrao"
0088: 
0089: 
0090: def _is_monthfm_command(text_value: str | None) -> bool:
0091:     return _command_name(text_value) == "/monthfm"
0092: 
```

## atalho direto do comando /tigrao antes do dispatcher — linhas 161-192

```python
0161: async def _handle_tigrao_direct(update: Update) -> bool:
0162:     message = update.message
0163:     if not message:
0164:         logger.warning("TIGRAO_DIRECT_SKIP | reason=no_message | update_id=%s", update.update_id)
0165:         return False
0166:     if not _is_tigrao_command(message.text):
0167:         return False
0168:     logger.warning(
0169:         "TIGRAO_DIRECT_RECEIVED | update_id=%s | chat_type=%s | chat_id=%s | from_id=%s | token=%s",
0170:         update.update_id,
0171:         getattr(message.chat, "type", None),
0172:         getattr(message.chat, "id", None),
0173:         getattr(message.from_user, "id", None),
0174:         _first_token(message.text),
0175:     )
0176:     if not is_owner_private_message(message):
0177:         logger.warning(
0178:             "TIGRAO_DIRECT_DENIED | update_id=%s | chat_type=%s | from_id=%s",
0179:             update.update_id,
0180:             getattr(message.chat, "type", None),
0181:             getattr(message.from_user, "id", None),
0182:         )
0183:         return True
0184:     logger.warning(
0185:         "TIGRAO_DIRECT_ALLOWED | update_id=%s | chat_type=%s | from_id=%s",
0186:         update.update_id,
0187:         message.chat.type,
0188:         message.from_user.id if message.from_user else None,
0189:     )
0190:     await message.answer(home_text(), reply_markup=home_keyboard())
0191:     logger.warning("TIGRAO_DIRECT_ANSWER_SENT | update_id=%s", update.update_id)
0192:     return True
```

## tratamento direto de waiting_for texto/mídia — linhas 278-326

```python
0278: async def _handle_tigrao_waiting_text_direct(update: Update) -> bool:
0279:     message = update.message
0280:     if not message or not message.text:
0281:         return False
0282:     if not is_owner_private_message(message):
0283:         return False
0284:     session = get_session()
0285:     if session.waiting_for not in TIGRAO_TEXT_WAITING_STATES:
0286:         return False
0287:     logger.warning(
0288:         "TIGRAO_WAITING_TEXT_DIRECT | update_id=%s | waiting_for=%s | selected_action=%s | selected_chat_id=%s | from_id=%s | token=%s",
0289:         update.update_id,
0290:         session.waiting_for,
0291:         session.selected_action,
0292:         session.selected_chat_id,
0293:         message.from_user.id if message.from_user else None,
0294:         _first_token(message.text),
0295:     )
0296:     if session.waiting_for == "ddx_add_words":
0297:         await tigrao_ddx_receive_add_words(message)
0298:     elif session.waiting_for == "ddx_remove_words":
0299:         await tigrao_ddx_receive_remove_words(message)
0300:     elif session.waiting_for in {"member_tag_user_id", "member_tag_value"}:
0301:         await tigrao_member_tag_receive_text(message)
0302:     else:
0303:         await tigrao_private_text(message)
0304:     return True
0305: 
0306: 
0307: async def _handle_tigrao_waiting_media_direct(update: Update) -> bool:
0308:     message = update.message
0309:     if not message:
0310:         return False
0311:     if not is_owner_private_message(message):
0312:         return False
0313:     session = get_session()
0314:     if session.waiting_for != "customize_photo":
0315:         return False
0316:     logger.warning(
0317:         "TIGRAO_WAITING_MEDIA_DIRECT | update_id=%s | waiting_for=%s | selected_chat_id=%s | from_id=%s | has_photo=%s | has_document=%s",
0318:         update.update_id,
0319:         session.waiting_for,
0320:         session.selected_chat_id,
0321:         message.from_user.id if message.from_user else None,
0322:         bool(message.photo),
0323:         bool(message.document),
0324:     )
0325:     await tigrao_receive_group_photo(message)
0326:     return True
```

## registro direto dos routers Tigrão — linhas 360-372

```python
0360:             default=DefaultBotProperties(parse_mode=ParseMode.HTML),
0361:         )
0362:         if not _telegram_dispatcher_configured:
0363:             dispatcher.include_router(tigrao_ddx_router)
0364:             dispatcher.include_router(tigrao_ddx_soft_router)
0365:             dispatcher.include_router(tigrao_customize_router)
0366:             dispatcher.include_router(tigrao_member_tag_router)
0367:             dispatcher.include_router(tigrao_pinned_media_router)
0368:             dispatcher.include_router(tigrao_new_member_watch_router)  # Sprint X4
0369:             dispatcher.include_router(tigrao_inline_x9_router)  # Sprint X9
0370:             dispatcher.include_router(tigrao_router)
0371:             dispatcher.include_router(monthfm_router)
0372:             dispatcher.include_router(weekfm_router)
```

## propagação de current_user para ContextVar — linhas 489-495

```python
0489:         # Correção do FSM (co-moderação): propaga o user_id corrente pros
0490:         # ContextVars das sessões ANTES de qualquer handler (diretos +
0491:         # dispatcher). Garante que cada moderador opere na própria sessão
0492:         # FSM, sem sobrescrever a do outro quando moderam ao mesmo tempo.
0493:         _current_uid = _extract_update_user_id(update)
0494:         tigrao_set_current_user(_current_uid)
0495:         btb_set_current_user(_current_uid)
```

## pipeline pré-dispatch com Tigrão/DDX/NMW — linhas 514-589

```python
0514:             tigraoresponde_handled = await handle_tigraoresponde_update(bot, update)
0515:         except Exception:
0516:             logger.exception("TIGRAORESPONDE_FAILED | update_id=%s", update.update_id)
0517:             tigraoresponde_handled = False
0518:         if tigraoresponde_handled:
0519:             return {"ok": True}
0520:         try:
0521:             tigrao_handled = await _handle_tigrao_direct(update)
0522:         except Exception:
0523:             logger.exception("TIGRAO_DIRECT_FAILED | update_id=%s", update.update_id)
0524:             tigrao_handled = False
0525:         if tigrao_handled:
0526:             return {"ok": True}
0527:         try:
0528:             monthfm_handled = await _handle_monthfm_direct(update)
0529:         except Exception:
0530:             logger.exception("MONTHFM_DIRECT_FAILED | update_id=%s", update.update_id)
0531:             monthfm_handled = False
0532:         if monthfm_handled:
0533:             return {"ok": True}
0534:         try:
0535:             weekfm_handled = await _handle_weekfm_direct(update)
0536:         except Exception:
0537:             logger.exception("WEEKFM_DIRECT_FAILED | update_id=%s", update.update_id)
0538:             weekfm_handled = False
0539:         if weekfm_handled:
0540:             return {"ok": True}
0541:         try:
0542:             btb_handled = await _handle_btb_direct(update)
0543:         except Exception:
0544:             logger.exception("BTB_DIRECT_FAILED | update_id=%s", update.update_id)
0545:             btb_handled = False
0546:         if btb_handled:
0547:             return {"ok": True}
0548:         try:
0549:             btb_waiting_handled = await _handle_btb_waiting_text_direct(update)
0550:         except Exception:
0551:             logger.exception("BTB_WAITING_TEXT_DIRECT_FAILED | update_id=%s", update.update_id)
0552:             btb_waiting_handled = False
0553:         if btb_waiting_handled:
0554:             return {"ok": True}
0555:         try:
0556:             tigrao_waiting_media_handled = await _handle_tigrao_waiting_media_direct(update)
0557:         except Exception:
0558:             logger.exception("TIGRAO_WAITING_MEDIA_DIRECT_FAILED | update_id=%s", update.update_id)
0559:             tigrao_waiting_media_handled = False
0560:         if tigrao_waiting_media_handled:
0561:             return {"ok": True}
0562:         try:
0563:             tigrao_waiting_text_handled = await _handle_tigrao_waiting_text_direct(update)
0564:         except Exception:
0565:             logger.exception("TIGRAO_WAITING_TEXT_DIRECT_FAILED | update_id=%s", update.update_id)
0566:             tigrao_waiting_text_handled = False
0567:         if tigrao_waiting_text_handled:
0568:             return {"ok": True}
0569:         # Sprint X4: observa membros novos + msgs com link e dispara DM ao
0570:         # owner ANTES do DDX. Nunca consome o update (sempre retorna False);
0571:         # falhas silenciosas pra não atrapalhar o pipeline normal.
0572:         try:
0573:             await tigrao_new_member_watch_preprocess_update(bot, update)
0574:         except Exception:
0575:             logger.exception("TIGRAO_NMW_PREPROCESS_FAILED | update_id=%s", update.update_id)
0576:         try:
0577:             ddx_handled = await tigrao_ddx_preprocess_update(bot, update)
0578:         except Exception:
0579:             logger.exception("TIGRAO_DDX_PREPROCESS_FAILED | update_id=%s", update.update_id)
0580:             ddx_handled = False
0581:         if ddx_handled:
0582:             return {"ok": True}
0583:         # DDX Soft (lei dos 10 minutos): roda DEPOIS do hard. Nunca consome
0584:         # o update (sempre retorna False) — apenas agenda delete em 600s.
0585:         try:
0586:             await tigrao_ddx_soft_preprocess_update(bot, update)
0587:         except Exception:
0588:             logger.exception("TIGRAO_DDX_SOFT_PREPROCESS_FAILED | update_id=%s", update.update_id)
0589:         await dispatcher.feed_update(bot, update)
```
