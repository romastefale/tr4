# Snippets de integração: `app/bot/telegram.py`

## reaction_audit importado para capturar reactions — linhas 29-31

```python
0029: from app.services.reaction_audit import reaction_audit_service
0030: from app.services.spotify import spotify_service
0031: 
```

## captura de message_reaction para reaction_audit — linhas 780-825

```python
0780:     async def on_message_reaction(event: MessageReactionUpdated) -> None:
0781:         """Sprint 8: tracking de reactions nos cards /playing.
0782: 
0783:         Telegram envia este update toda vez que um user adiciona/remove
0784:         reaction numa mensagem em grupo onde o bot é admin. Se a mensagem
0785:         for um card trackado (existe em card_messages), grava o diff em
0786:         track_reactions. Caso contrário, ignora silenciosamente.
0787:         """
0788:         if not event.user:
0789:             return  # reaction anônima (rara) ou de canal — ignora
0790:         old_emojis = [
0791:             r.emoji for r in (event.old_reaction or [])
0792:             if hasattr(r, "emoji") and getattr(r, "emoji", None)
0793:         ]
0794:         new_emojis = [
0795:             r.emoji for r in (event.new_reaction or [])
0796:             if hasattr(r, "emoji") and getattr(r, "emoji", None)
0797:         ]
0798:         try:
0799:             await reactions_service.apply_reaction_change(
0800:                 chat_id=event.chat.id,
0801:                 message_id=event.message_id,
0802:                 user_id=event.user.id,
0803:                 old_emojis=old_emojis,
0804:                 new_emojis=new_emojis,
0805:             )
0806:         except Exception:
0807:             logger.exception(
0808:                 "MESSAGE_REACTION_FAILED chat=%s msg=%s user=%s",
0809:                 event.chat.id, event.message_id, event.user.id,
0810:             )
0811:         # Sprint X3: log paralelo na tabela de auditoria (TTL 24h) pra
0812:         # o painel rmod listar quem reagiu numa msg/chat sem depender
0813:         # de @username. Falha aqui NÃO deve abortar o fluxo principal
0814:         # de tracking de cards — wrap independente.
0815:         try:
0816:             await reaction_audit_service.record_change(
0817:                 chat_id=event.chat.id,
0818:                 message_id=event.message_id,
0819:                 user_id=event.user.id,
0820:                 user_name=getattr(event.user, "full_name", None),
0821:                 user_username=getattr(event.user, "username", None),
0822:                 old_emojis=old_emojis,
0823:                 new_emojis=new_emojis,
0824:             )
0825:         except Exception:
```

## reserva de inline X9 no inline musical — linhas 831-864

```python
0831:     # Inline público (usuários comuns). Query vazia (ou "playing") -> card da
0832:     # música tocando como 1ª opção. Query com termo -> busca por termo (mesmo
0833:     # motor do /radiofm). O formato owner-only de moderação X9
0834:     # (`<chat_id> <user_id>`, dois inteiros) é EXCLUÍDO via filter pra cair no
0835:     # sub-router de moderação — root é testado antes dos sub_routers em aiogram3.
0836:     def _is_x9_inline_format(query: InlineQuery) -> bool:
0837:         parts = (query.query or "").strip().split()
0838:         if len(parts) != 2:
0839:             return False
0840:         return all(p.lstrip("-").isdigit() for p in parts)
0841: 
0842:     async def _answer_playing(query: InlineQuery) -> None:
0843:         track = await music_service.get_current_or_last_played(query.from_user.id)
0844:         if not track:
0845:             await query.answer([], cache_time=1, is_personal=True)
0846:             return
0847:         track_name, artist, track_url, cover = _track_label(track)
0848:         if not cover:
0849:             await query.answer([], cache_time=1, is_personal=True)
0850:             return
0851:         who = html.escape(query.from_user.full_name or "Usuário")
0852:         track_part = f'<a href="{track_url}">{track_name}</a>' if track_url else track_name
0853:         caption = f"<i>{who} · {track_part} - {artist}</i>"
0854:         result = InlineQueryResultPhoto(
0855:             id=str(uuid.uuid4()),
0856:             photo_url=cover,
0857:             thumbnail_url=cover,
0858:             caption=caption,
0859:             parse_mode="HTML",
0860:         )
0861:         await query.answer([result], cache_time=2, is_personal=True)
0862: 
0863:     @dp.inline_query(lambda q: not _is_x9_inline_format(q))
0864:     async def inline_public(query: InlineQuery) -> None:
```

## guard owner_dialog_active para não consumir diálogo Tigrão — linhas 903-926

```python
0903:     # `waiting_for` dos sub-routers tigrao/btb (rmod_link, customize_title,
0904:     # outbound_text, btb tadd/gmanual, etc), causando silêncio do bot.
0905:     def _owner_dialog_active(message: Message) -> bool:
0906:         # Lazy imports evitam ciclo (telegram.py é importado antes dos
0907:         # routers em main.py). Try/except por segurança caso módulo falhe.
0908:         try:
0909:             from app.moderation_tigrao.permissions import is_owner_private_message
0910:         except Exception:
0911:             return False
0912:         if not is_owner_private_message(message):
0913:             return False
0914:         try:
0915:             from app.moderation_tigrao.state import get_session as _tigrao_session
0916:             if _tigrao_session().waiting_for is not None:
0917:                 return True
0918:         except Exception:
0919:             pass
0920:         try:
0921:             from app.btb.state import get_session as _btb_session
0922:             if _btb_session().waiting_for is not None:
0923:                 return True
0924:         except Exception:
0925:             pass
0926:         return False
```
