# Snippets de integração: `app/db/database.py`

## DDL reaction_audit — linhas 200-243

```python
0200:                     text(
0201:                         """
0202:                         CREATE TABLE IF NOT EXISTS reaction_audit (
0203:                             id SERIAL PRIMARY KEY,
0204:                             chat_id BIGINT NOT NULL,
0205:                             message_id BIGINT NOT NULL,
0206:                             user_id BIGINT NOT NULL,
0207:                             user_name VARCHAR,
0208:                             user_username VARCHAR,
0209:                             emoji VARCHAR NOT NULL,
0210:                             created_at TIMESTAMP NOT NULL,
0211:                             CONSTRAINT uq_reaction_audit_msg_user_emoji
0212:                                 UNIQUE (chat_id, message_id, user_id, emoji)
0213:                         )
0214:                         """
0215:                     )
0216:                 )
0217:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_chat_id ON reaction_audit(chat_id)"))
0218:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_user_id ON reaction_audit(user_id)"))
0219:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_created_at ON reaction_audit(created_at)"))
0220:             else:
0221:                 conn.execute(
0222:                     text(
0223:                         """
0224:                         CREATE TABLE IF NOT EXISTS reaction_audit (
0225:                             id INTEGER PRIMARY KEY AUTOINCREMENT,
0226:                             chat_id INTEGER NOT NULL,
0227:                             message_id INTEGER NOT NULL,
0228:                             user_id INTEGER NOT NULL,
0229:                             user_name VARCHAR,
0230:                             user_username VARCHAR,
0231:                             emoji VARCHAR NOT NULL,
0232:                             created_at DATETIME NOT NULL,
0233:                             CONSTRAINT uq_reaction_audit_msg_user_emoji
0234:                                 UNIQUE (chat_id, message_id, user_id, emoji)
0235:                         )
0236:                         """
0237:                     )
0238:                 )
0239:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_chat_id ON reaction_audit(chat_id)"))
0240:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_user_id ON reaction_audit(user_id)"))
0241:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_reaction_audit_created_at ON reaction_audit(created_at)"))
0242:         except Exception:
0243:             logger.warning("Sprint X3 reaction_audit table creation failed", exc_info=True)
```

## DDL new_member_watch — linhas 246-292

```python
0246:         # preprocessor `new_member_watch_runtime` pra alertar o owner via
0247:         # DM quando user recém-entrado posta link nas primeiras 5 msgs.
0248:         try:
0249:             if dialect_name == "postgresql":
0250:                 conn.execute(
0251:                     text(
0252:                         """
0253:                         CREATE TABLE IF NOT EXISTS new_member_watch (
0254:                             id SERIAL PRIMARY KEY,
0255:                             chat_id BIGINT NOT NULL,
0256:                             user_id BIGINT NOT NULL,
0257:                             user_name VARCHAR,
0258:                             user_username VARCHAR,
0259:                             joined_at TIMESTAMP NOT NULL,
0260:                             alerts_sent INTEGER NOT NULL DEFAULT 0,
0261:                             CONSTRAINT uq_new_member_watch_chat_user
0262:                                 UNIQUE (chat_id, user_id)
0263:                         )
0264:                         """
0265:                     )
0266:                 )
0267:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_chat_id ON new_member_watch(chat_id)"))
0268:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_user_id ON new_member_watch(user_id)"))
0269:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_joined_at ON new_member_watch(joined_at)"))
0270:             else:
0271:                 conn.execute(
0272:                     text(
0273:                         """
0274:                         CREATE TABLE IF NOT EXISTS new_member_watch (
0275:                             id INTEGER PRIMARY KEY AUTOINCREMENT,
0276:                             chat_id INTEGER NOT NULL,
0277:                             user_id INTEGER NOT NULL,
0278:                             user_name VARCHAR,
0279:                             user_username VARCHAR,
0280:                             joined_at DATETIME NOT NULL,
0281:                             alerts_sent INTEGER NOT NULL DEFAULT 0,
0282:                             CONSTRAINT uq_new_member_watch_chat_user
0283:                                 UNIQUE (chat_id, user_id)
0284:                         )
0285:                         """
0286:                     )
0287:                 )
0288:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_chat_id ON new_member_watch(chat_id)"))
0289:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_user_id ON new_member_watch(user_id)"))
0290:                 conn.execute(text("CREATE INDEX IF NOT EXISTS ix_new_member_watch_joined_at ON new_member_watch(joined_at)"))
0291:         except Exception:
0292:             logger.warning("Sprint X4 new_member_watch table creation failed", exc_info=True)
```

## import dos modelos Sprint X3/X4 — linhas 320-327

```python
0320:         from app.models.lastfm_profile import LastfmProfile  # noqa: F401
0321:         from app.models.spotify_token import SpotifyToken  # noqa: F401
0322:         from app.models.track_like import TrackLike  # noqa: F401
0323:         from app.models.track_play import TrackPlay  # noqa: F401
0324:         from app.models.track_reaction import TrackReaction  # noqa: F401  # Sprint 8
0325:         from app.models.reaction_audit import ReactionAudit  # noqa: F401  # Sprint X3
0326:         from app.models.new_member_watch import NewMemberWatch  # noqa: F401  # Sprint X4
0327: 
```
